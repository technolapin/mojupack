# v1.1.0

Created the modpack with mods in it.

# v1.1.1

Removed lame mods.
